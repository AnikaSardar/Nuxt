<template>
    <div>
        <EventList />
    </div>
</template>

<script setup>
definePageMeta({
    middleware: ['commonauth']
})
</script>

<style scoped>
</style>