<template>
    <div>
        <NewEventList />
    </div>
</template>

<script setup>
useHead({
    title: 'New Event List'
})
</script>

<style scoped>

</style>