<template>
    <div>
    </div>
</template>

<script setup>

definePageMeta({
  layout: 'login'
})
</script>

<style scoped>
</style>