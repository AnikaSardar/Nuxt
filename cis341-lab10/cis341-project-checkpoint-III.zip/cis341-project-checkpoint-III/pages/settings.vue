<template>
    <div>
        <p>Settings</p>
    </div>
</template>

<script setup>
useHead({
    title: 'Settings'
})
</script>

<style scoped>
</style>