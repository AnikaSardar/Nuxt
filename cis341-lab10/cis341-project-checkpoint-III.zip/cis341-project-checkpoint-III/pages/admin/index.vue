<template>
    <div>
    </div>
</template>

<script setup>
  definePageMeta({
    middleware: ['admin-auth'],  // Apply the adminAuth middleware to this page
  });
</script>

<style scoped>
</style>