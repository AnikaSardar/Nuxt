<template>
    <div>
        <NuxtLink to="/admin/eventList">Go back to Event List</NuxtLink>
        <NewEventList />
    </div>
</template>

<script setup>
useHead({
    title: 'New Events'
})

</script>

<style scoped>

</style>