<template>
    <div>

    </div>
</template>

<script setup>
definePageMeta({
    middleware: ['registereduserauth']
})
</script>

<style scoped>
</style>