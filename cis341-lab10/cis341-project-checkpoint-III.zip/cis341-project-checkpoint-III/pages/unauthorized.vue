<template>
    <div>
        <h1>401</h1>
        <h2>Authorization Required</h2>
        <h3><em>You are not authorized for selected action. Please either login to a more priviledged account or navigate back to home.</em></h3>
        <p><NuxtLink to="/">Back to Home</NuxtLink></p>
    </div>
</template>

<script setup>
</script>

<style scoped>

</style>

