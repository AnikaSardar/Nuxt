<template>
    <div>
        <PastEventList />
    </div>
</template>

<script setup>
useHead({
    title: 'Past Event List'
})
</script>

<style scoped>

</style>