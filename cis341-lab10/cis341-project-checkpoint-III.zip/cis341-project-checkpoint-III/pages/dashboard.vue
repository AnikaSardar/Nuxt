<template>
    <div>
        <h1>Dashboard</h1>
        <Dashboard />
    </div>
</template>

<script setup>
useHead({
    title: 'Dashboard'
})
// definePageMeta({
//     middleware: ['admin-auth'],  // Apply the adminAuth middleware to this page
//   });
</script>

<style scoped>
</style>