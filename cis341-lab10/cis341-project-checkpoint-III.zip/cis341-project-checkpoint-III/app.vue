<template>
  <div>
    <NuxtLayout>
    </NuxtLayout>
  </div>
</template>


