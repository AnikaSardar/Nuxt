<template>
    <div>
        <p>User Profile</p>
    </div>
</template>

<script setup>

</script>

<style scoped>

</style>