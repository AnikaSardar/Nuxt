<template>
    <header class="header">
        <NuxtLink to ="/">Event Planner App</NuxtLink>
    </header>
</template>

<script setup>
</script>

<style scoped>
@import url("~/assets/css/header.css");
</style>