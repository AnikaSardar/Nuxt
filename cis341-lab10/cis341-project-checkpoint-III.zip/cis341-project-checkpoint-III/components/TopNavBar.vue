<template>
    <div>
        <!-- TODO: ADD CSS/USE BOOTSTRAP-->
        <aside class="nav-bar">
            <nav>
                <Header />
                <ul>
                    <li><ProfileDropDown /></li>    
                </ul>
            </nav>
        </aside>
    </div>
</template>

<script setup>
</script>
<style>
@import url("~/assets/css/top-navbar.css");
</style>