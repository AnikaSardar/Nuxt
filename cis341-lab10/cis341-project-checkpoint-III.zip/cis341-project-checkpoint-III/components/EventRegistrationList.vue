<template>
    <div>
        <!-- Render a Vue list using v-for. -->
         <p>Event Registration List</p>
    </div>
</template>

<script setup>

</script>

<style scoped></style>