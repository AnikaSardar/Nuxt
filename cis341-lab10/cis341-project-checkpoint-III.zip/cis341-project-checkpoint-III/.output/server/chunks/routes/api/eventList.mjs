import { c as defineEventHandler, e as createError } from '../../_/nitro.mjs';
import { u as useApiLayer } from '../../_/useApiLayer.mjs';
import authorizeRoute from './authorizeRoute.mjs';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:fs';
import 'node:url';

const eventList = defineEventHandler(async (event) => {
  const { getEvents } = useApiLayer();
  try {
    await authorizeRoute(event, ["admin", "event_owner", "registered_user"]);
    return await getEvents();
  } catch (error) {
    throw createError({
      statusCode: 500,
      statusMessage: "Failed to fetch events.",
      data: error
    });
  }
});

export { eventList as default };
//# sourceMappingURL=eventList.mjs.map
