import { c as defineEventHandler, r as readBody, e as createError, f as useSession } from '../../../_/nitro.mjs';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:fs';
import 'node:url';

const login = defineEventHandler(async (event) => {
  const body = await readBody(event);
  try {
    const users = await $fetch("http://localhost:3333/events_registered_users");
    const events_roles = await $fetch("http://localhost:3333/events_roles");
    const user = users.find(
      (u) => u.username === body.username && u.password === body.password
    );
    const eventRole = getEventRole(events_roles, user);
    if (!user) {
      throw createError({
        statusCode: 401,
        statusMessage: "Invalid credentials!"
      });
    }
    const session = await useSession(event, {
      name: "auth-session",
      password: "G4tE8dL9aM5oN2yT6pR8qA9jI#8dL4bG7n8sK5aL2hJ$eK4M8cB9dY6FpQ",
      cookie: {
        httpOnly: true,
        secure: true
      }
    });
    await session.update({ role: eventRole || "admin" });
    return {
      id: user.id,
      username: user.username,
      fullName: user.full_name,
      role: eventRole || "user"
    };
  } catch (error) {
    throw createError({
      statusCode: 401,
      statusMessage: "Invalid credentials!"
    });
  }
});
function getEventRole(events_roles, user) {
  const role = events_roles.find((role2) => role2.id === user.id);
  return role ? role.name.toLowerCase() : null;
}

export { login as default };
//# sourceMappingURL=login.mjs.map
