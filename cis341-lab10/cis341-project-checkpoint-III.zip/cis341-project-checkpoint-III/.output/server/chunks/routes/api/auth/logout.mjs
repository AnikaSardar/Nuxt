import { c as defineEventHandler, u as useRuntimeConfig, g as getCookie, f as useSession } from '../../../_/nitro.mjs';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:fs';
import 'node:url';

const logout = defineEventHandler(async (event) => {
  const runtimeConfig = useRuntimeConfig();
  const authCookie = getCookie(event, runtimeConfig.authCookieName);
  if (authCookie) {
    const session = await useSession(event, {
      name: runtimeConfig.authCookieName,
      password: runtimeConfig.sessionPassword
    });
    await session.clear();
    return { success: true };
  } else {
    return { success: false };
  }
});

export { logout as default };
//# sourceMappingURL=logout.mjs.map
