import { c as defineEventHandler, e as createError } from '../../_/nitro.mjs';
import { u as useApiLayer } from '../../_/useApiLayer.mjs';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:fs';
import 'node:url';

const eventsRegisteredUsers = defineEventHandler(async (event) => {
  const { getRegisteredUsers } = useApiLayer();
  try {
    return await getRegisteredUsers();
  } catch (error) {
    throw createError({
      statusCode: 500,
      statusMessage: "Failed to fetch registered users.",
      data: error
    });
  }
});

export { eventsRegisteredUsers as default };
//# sourceMappingURL=eventsRegisteredUsers.mjs.map
