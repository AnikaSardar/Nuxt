import { c as defineEventHandler, e as createError } from '../../_/nitro.mjs';
import { u as useApiLayer } from '../../_/useApiLayer.mjs';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:fs';
import 'node:url';

const users = defineEventHandler(async (event) => {
  const { getUsers } = useApiLayer();
  try {
    return await getUsers();
  } catch (error) {
    throw createError({
      statusCode: 500,
      statusMessage: "Failed to fetch users.",
      data: error
    });
  }
});

export { users as default };
//# sourceMappingURL=users.mjs.map
