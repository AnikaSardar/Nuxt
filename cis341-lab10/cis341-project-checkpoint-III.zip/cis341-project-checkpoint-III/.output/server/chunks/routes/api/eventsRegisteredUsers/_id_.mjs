import { c as defineEventHandler, e as createError } from '../../../_/nitro.mjs';
import { u as useApiLayer } from '../../../_/useApiLayer.mjs';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:fs';
import 'node:url';

const _id_ = defineEventHandler(async (event) => {
  const { id } = event.context.params;
  const { getRegisteredUserDetails } = useApiLayer();
  if (!parseInt(id)) {
    throw createError({
      statusCode: 400,
      statusMessage: "Invalid user ID."
    });
  }
  try {
    return await getRegisteredUserDetails(id);
  } catch (error) {
    throw createError({
      statusCode: 500,
      statusMessage: `Failed to fetch registered user with ID ${id}.`,
      data: error
    });
  }
});

export { _id_ as default };
//# sourceMappingURL=_id_.mjs.map
