import { c as defineEventHandler, e as createError } from '../../../_/nitro.mjs';
import { u as useApiLayer } from '../../../_/useApiLayer.mjs';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:fs';
import 'node:url';

const _id_ = defineEventHandler(async (event) => {
  const event_id = event.context.params.id;
  const { getEventFeedback } = useApiLayer();
  if (!parseInt(event_id)) {
    throw createError({ statusCode: 400, statusMessage: "Invalid event ID." });
  }
  try {
    return await getEventFeedback(event_id);
  } catch (error) {
    throw createError({
      statusCode: 500,
      statusMessage: `Failed to fetch feedback for event with ID ${event_id}.`,
      data: error
    });
  }
});

export { _id_ as default };
//# sourceMappingURL=_id_.mjs.map
