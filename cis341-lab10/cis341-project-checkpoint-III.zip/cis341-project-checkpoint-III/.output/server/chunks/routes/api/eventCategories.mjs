import { c as defineEventHandler, e as createError } from '../../_/nitro.mjs';
import { u as useApiLayer } from '../../_/useApiLayer.mjs';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:fs';
import 'node:url';

const eventCategories = defineEventHandler(async (event) => {
  const { getEventCategories } = useApiLayer();
  try {
    return await getEventCategories();
  } catch (error) {
    throw createError({
      statusCode: 500,
      statusMessage: "Failed to fetch event types.",
      data: error
    });
  }
});

export { eventCategories as default };
//# sourceMappingURL=eventCategories.mjs.map
