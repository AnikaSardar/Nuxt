import { u as useRuntimeConfig, g as getCookie, f as useSession, e as createError } from '../../_/nitro.mjs';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:fs';
import 'node:url';

const authorizeRoute = async (event, roles) => {
  const runtimeConfig = useRuntimeConfig();
  const authCookie = getCookie(event, runtimeConfig.authCookieName);
  if (authCookie) {
    const session = await useSession(event, {
      name: runtimeConfig.authCookieName,
      password: runtimeConfig.sessionPassword
    });
    if (roles.includes(session.data.role)) {
      return true;
    } else {
      throw createError({
        statusCode: 401,
        statusMessage: "Not authorized to access endpoint!"
      });
    }
  } else {
    throw createError({
      statusCode: 401,
      statusMessage: "Not authenticated!"
    });
  }
};

export { authorizeRoute as default };
//# sourceMappingURL=authorizeRoute.mjs.map
