import { e as createError } from './nitro.mjs';

const useApiLayer = () => {
  const baseUrl = "http://localhost:3333";
  const getUsers = async () => {
    try {
      const users = await $fetch(`${baseUrl}/users`);
      return users;
    } catch (error) {
      throw createError({
        statusCode: 500,
        statusMessage: "Failed to fetch users from JSON Server.",
        data: error
      });
    }
  };
  const getUserDetails = async (id) => {
    try {
      const user = await $fetch(`${baseUrl}/users/${id}`);
      return user;
    } catch (error) {
      throw createError({
        statusCode: 500,
        statusMessage: `Failed to fetch user with ID ${id} from JSON Server.`,
        data: error
      });
    }
  };
  const getRegisteredUsers = async () => {
    const { data, error } = await useFetch("/api/events_registered_users");
    if (error) throw new Error("Failed to fetch registered users.");
    return data;
  };
  const getRegisteredUserDetails = async (id) => {
    const { data, error } = await useFetch(`/api/events_registered_users/${id}`);
    if (error) throw new Error(`Failed to fetch registered user with ID ${id}.`);
    return data;
  };
  const getEventCategories = async () => {
    try {
      const eventCategories = await $fetch(`${baseUrl}/eventCategories`);
      return eventCategories;
    } catch (error) {
      throw createError({
        statusCode: 500,
        statusMessage: "Failed to fetch event types from JSON Server.",
        data: error
      });
    }
  };
  const getEventCategoryDetails = async (id) => {
    try {
      const user = await $fetch(`${baseUrl}/eventCategories/${id}`);
      return user;
    } catch (error) {
      throw createError({
        statusCode: 500,
        statusMessage: `Failed to fetch event-type with ID ${id} from JSON Server.`,
        data: error
      });
    }
  };
  const getEvents = async () => {
    try {
      const events = await $fetch(`${baseUrl}/events`);
      return events;
    } catch (error) {
      throw createError({
        statusCode: 500,
        statusMessage: "Failed to fetch events from JSON Server.",
        data: error
      });
    }
  };
  const getEventDetails = async (id) => {
    try {
      const event = await $fetch(`${baseUrl}/events/${id}`);
      const eventType = await $fetch(`${baseUrl}/events_types/${event.type_id}`);
      const eventOwner = await $fetch(`${baseUrl}/events_registered_users/${event.owner_id}`);
      return { ...event, eventType, eventOwner };
    } catch (error) {
      throw createError({
        statusCode: 500,
        statusMessage: `Failed to fetch event with ID ${id} from JSON Server.`,
        data: error
      });
    }
  };
  const createRSVP = async (rsvp) => {
    try {
      const response = await $fetch(`${baseUrl}/events_rsvps`, {
        method: "POST",
        body: rsvp
        // Pass RSVP data to the JSON Server
      });
      return response;
    } catch (error) {
      throw createError({
        statusCode: 500,
        statusMessage: "Failed to create RSVP on JSON Server.",
        data: error
      });
    }
  };
  const submitFeedback = async (feedback) => {
    try {
      const response = await $fetch(`${baseUrl}/events_feedback`, {
        method: "POST",
        body: feedback
        // Pass feedback data to the JSON Server
      });
      return response;
    } catch (error) {
      throw createError({
        statusCode: 500,
        statusMessage: "Failed to submit feedback to JSON Server.",
        data: error
      });
    }
  };
  const getEventFeedback = async (eventId) => {
    try {
      const feedback = await $fetch(`${baseUrl}/events_feedback?event_id=${eventId}`);
      return feedback;
    } catch (error) {
      throw createError({
        statusCode: 500,
        statusMessage: `Failed to fetch feedback for event with ID ${eventId} from JSON Server.`,
        data: error
      });
    }
  };
  return {
    getUsers,
    getUserDetails,
    getRegisteredUsers,
    getEventCategories,
    getEventCategoryDetails,
    getEvents,
    getEventDetails,
    createRSVP,
    submitFeedback,
    getEventFeedback,
    getRegisteredUserDetails
  };
};

export { useApiLayer as u };
//# sourceMappingURL=useApiLayer.mjs.map
