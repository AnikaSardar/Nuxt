import{G as e,H as o}from"./BwQ91Khw.js";import{u as a}from"./RcJQoTCn.js";const n=e((i,r)=>{const{isAuthenticated:t}=a();if(!t())return o("/login")});export{n as default};
