import{m as t,c as n,b as o,o as a}from"./BwQ91Khw.js";const m={__name:"eventManagement",setup(s){return(c,r)=>{const e=t("EventList");return a(),n("div",null,[o(e)])}}};export{m as default};
