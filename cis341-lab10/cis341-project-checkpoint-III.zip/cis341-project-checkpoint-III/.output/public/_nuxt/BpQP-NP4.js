import{c as e,o}from"./BwQ91Khw.js";const n={__name:"login",setup(t){return(c,r)=>(o(),e("div"))}};export{n as default};
