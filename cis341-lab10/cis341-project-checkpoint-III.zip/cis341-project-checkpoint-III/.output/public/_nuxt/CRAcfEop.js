import{_ as n,o,c as r,a as t}from"./BwQ91Khw.js";const s={};function _(c,e){return o(),r("div",null,e[0]||(e[0]=[t("p",null,"User Profile",-1)]))}const l=n(s,[["render",_]]);export{l as _};
