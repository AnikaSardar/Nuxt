import{c as e,o as t}from"./BwQ91Khw.js";const n={__name:"index",setup(c){return(o,r)=>(t(),e("div"))}};export{n as default};
